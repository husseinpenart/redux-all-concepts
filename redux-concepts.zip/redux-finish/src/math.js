export const isEven = number => number % 2 === 0;
